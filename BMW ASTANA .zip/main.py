from aiogram import types, Bot, Dispatcher, executor
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters import Text
from aiogram.dispatcher.filters.state import StatesGroup, State
from aiogram.types import CallbackQuery
import sqlite3 as sq

bot = Bot(token='6092517590:AAH_2z-IpOG7GtcyuoTOOf4OvvFjahUsnHE')

storage = MemoryStorage()


dp = Dispatcher(bot, storage=storage)

add_menu = types.InlineKeyboardMarkup()
btn_mod = types.InlineKeyboardButton(text="Модель түрін қосу", callback_data="modelkosu")
btn_kyzmet = types.InlineKeyboardButton(text="Автомобиль қосу", callback_data="addavto")
btn_zapis = types.InlineKeyboardButton(text="Записьтерді қарау", callback_data="zapistar")
add_menu.add(btn_mod,btn_kyzmet,btn_zapis)

kb = types.ReplyKeyboardMarkup(resize_keyboard=True)
btn_ya = types.KeyboardButton(text="пікір қалдыру")
btn_jok = types.KeyboardButton(text="пікір оқу")
kb.add(btn_ya, btn_jok)


base = sq.connect('project.db')

cursor = base.cursor()

cursor.execute('''CREATE TABLE IF NOT EXISTS model_turleri(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT)''')

cursor.execute('''CREATE TABLE IF NOT EXISTS models(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                type_id INTEGER,
                name TEXT,
                desc TEXT,
                price INTEGER,
                photo TEXT)''')

cursor.execute('''CREATE TABLE IF NOT EXISTS sebet1(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                model_id INTEGER)''')

cursor.execute('''CREATE TABLE IF NOT EXISTS otzyv(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                otzyvy TEXT)''')
cursor.execute('''CREATE TABLE IF NOT EXISTS client(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                number INTEGER,
                marka TEXT)''')

base.commit()

async def insert_otzov(state):
    async with state.proxy() as data:
        cursor.execute("INSERT INTO otzyv(otzyvy) values(?)",tuple(data.values()))
    base.commit()
    print('Пікір қосылды')

async def insert_zapic(state):
    async with state.proxy() as data:
        cursor.execute('INSERT INTO client(name,number,marka) values(?,?,?)',tuple(data.values()))
    base.commit()
    print('ZAPIS')

async def select_pikir(message):
    for res in cursor.execute('SELECT * FROM otzyv').fetchall():
        await message.answer(f'{res[1]}')

async def select_all_types(message):
    inline_menu = types.InlineKeyboardMarkup()
    for res in cursor.execute('SELECT * FROM model_turleri').fetchall():
        btn = types.InlineKeyboardButton(text=res[1], callback_data=res[1])
        inline_menu.add(btn)
    await message.answer("Біздің автосалонның модельдері: ", reply_markup=inline_menu)
    await message.answer('Сіз бізге өз пікірінізді қалдыра аласыз.',reply_markup=kb)



async def select_all(message):
    menu = types.ReplyKeyboardMarkup(resize_keyboard=True)
    for res in cursor.execute('SELECT * FROM model_turleri ').fetchall():
        btn = types.KeyboardButton(text=res[1])
        menu.add(btn)
    await message.answer("Қандай модель түрін қосқыңыз келеді:", reply_markup=menu)

async def insert_mod(state):
    async with state.proxy() as data:
        cursor.execute("INSERT INTO models(type_id,name,desc,price,photo) values(?,?,?,?,?)",tuple(data.values()))
    base.commit()
    print('database ok')

async def select_kolik(message, id):
    for ret in cursor.execute(f"SELECT id, name,desc,price,photo FROM models WHERE type_id='{id}'").fetchall():
        kb = types.InlineKeyboardMarkup()
        btn1 = types.InlineKeyboardButton(text="❤️", callback_data="qosu"+str(ret[0]))
        btn2 = types.InlineKeyboardButton(text="Избранные", callback_data="Sebetkeoty")
        kb.add(btn1,btn2)
        await message.answer_photo(ret[4],f"{ret[1]}\n{ret[2]}\n{ret[3]}", reply_markup=kb)

async def select_sebet(message):
    sebet = []
    for el in cursor.execute('SELECT model_id FROM sebet1').fetchall():
        sebet.append(el[0])
    d = {}
    for item in set(sebet):
        d[item] = sebet.count(item)
    for key in d:
        res = cursor.execute(f"SELECT * FROM models WHERE id='{key}'").fetchall()[0]
        kb1 = types.InlineKeyboardMarkup()
        btn_1 = types.InlineKeyboardButton(text="-", callback_data="alu"+str(res[0]))
        btn_2 = types.InlineKeyboardButton(text="Убрать из избранных", callback_data="SebettenOwiru")
        kb1.add(btn_1,btn_2)
        await message.answer_photo(res[5],f"{res[2]} {d[key]}\nБағасы = {res[4]*d[key]}",reply_markup=kb1)

async def select_all_zapis(message):
    for res in cursor.execute('SELECT * FROM client').fetchall():
        await message.answer(f'аты-{res[1]}\n Номеры-{res[2]}\nКөліктүрі-{res[3]}')

class adminFSM(StatesGroup):
    model_type_name = State()
    model_type_id = State()
    model_name = State()
    model_desc = State()
    model_price = State()
    model_photo = State()
    otzov_client = State()
    name_state = State()
    kolik_state = State()
    number_state = State()
    zapis_state = State()


@dp.message_handler(commands='start')
async def start(message:types.Message):
    await message.answer(text="BMW автосалонын таңдағаныңызға рахмет! Біздің бот арқылы сіз ойыңыздағы көлігіңізді сатып ала аласыз немесе сынақтан өткізе аласыз. Тест драйвқа жазылу командасы /testdrive. \n Біздің байланыс номер:87476717145")
    await select_all_types(message)

@dp.message_handler(Text(equals='пікір қалдыру'))
async def otzov(message:types.Message,state:FSMContext):
    await message.answer("Өз пікірінізді қалдырыныз.")
    await state.set_state(adminFSM.otzov_client)

@dp.message_handler(state=adminFSM.otzov_client)
async def otzov_add(message:types.Message, state: FSMContext):
    async with state.proxy() as data:
        data['otzyvy'] = message.text
    await insert_otzov(state)
    await  state.finish()
    await message.answer('Пікіріңізге рахмет!',reply_markup=kb)

@dp.message_handler(Text(equals='пікір оқу'))
async def read_otz(message:types.Message):
    await select_pikir(message)

@dp.callback_query_handler(Text(equals='zapistar'))
async def zapiss(callback:CallbackQuery):
    print(5)
    await select_all_zapis(callback.message)




@dp.message_handler(commands='add')
async def add_command(message:types.Message):
    await message.answer("Не қосқыңыз келеді:", reply_markup=add_menu)

@dp.callback_query_handler(Text(equals='modelkosu'))
async def type_kosu(callback:CallbackQuery, state:FSMContext):
    await callback.message.answer("Модель түрінің атауын еңгізіңіз:")
    await state.set_state(adminFSM.model_type_name)
    await callback.answer()

@dp.message_handler(state=adminFSM.model_type_name)
async def load_type(message:types.Message,state:FSMContext):
    print(message.text)
    cursor.execute(f"INSERT INTO model_turleri(name) values('{message.text}')")
    base.commit()
    print('database ok')
    await state.finish()

@dp.message_handler(commands='testdrive')
async def type_kosu(message:types.Message,state:FSMContext ):
    await message.answer("Аты жөніңізді еңгізіңіз:")
    await state.set_state(adminFSM.name_state)

@dp.message_handler(state=adminFSM.name_state)
async def client_name(message:types.Message, state:FSMContext):
    async with state.proxy() as data:
        data['name'] = message.text
    await message.answer("Телефон номеріңізді еңгізіңіз:")
    await state.set_state(adminFSM.number_state)

@dp.message_handler(state=adminFSM.number_state)
async def client_number(message:types.Message, state:FSMContext):
    async with state.proxy() as data:
        data['number'] = int(message.text)
    await message.answer("Таңдаған көлігіңіз:")
    await state.set_state(adminFSM.kolik_state)

@dp.message_handler(state=adminFSM.kolik_state)
async def client_kolik(message:types.Message, state:FSMContext):
    async with state.proxy() as data:
        data['kolik'] = message.text
    await insert_zapic(state)
    await state.finish()
    await message.answer("Сіз сәтті тіркелдіңіз. Операторлар сізбен хабарласады")

@dp.callback_query_handler(Text(equals='addavto'))
async def model_kosu(callback:CallbackQuery, state:FSMContext):
    await select_all(callback.message)
    await state.set_state(adminFSM.model_type_id)
    await callback.answer()

@dp.message_handler(state=adminFSM.model_type_id)
async def load_model_id(message:types.Message,state:FSMContext):
    id = cursor.execute(f"SELECT id FROM model_turleri WHERE name='{message.text}'").fetchall()[0][0]
    async with state.proxy() as data:
        data['id'] =id
    await state.set_state(adminFSM.model_name)
    await message.answer("Енді атауын еңгізіңіз:")

@dp.message_handler(state=adminFSM.model_name)
async def load_model_name(message:types.Message,state:FSMContext):
    async with state.proxy() as data:
        data['name'] = message.text
    await state.set_state(adminFSM.model_desc)
    await message.answer("Енді сипаттамасын еңгізіңіз:")

@dp.message_handler(state=adminFSM.model_desc)
async def load_model_desc(message:types.Message,state:FSMContext):
    async with state.proxy() as data:
        data['desc'] = message.text
    await state.set_state(adminFSM.model_price)
    await message.answer("Енді бағасын еңгізіңіз:")

@dp.message_handler(state=adminFSM.model_price)
async def load_model_price(message:types.Message,state:FSMContext):
    async with state.proxy() as data:
        data['price'] = int(message.text)
    await state.set_state(adminFSM.model_photo)
    await message.answer("Енді суретін еңгізіңіз:")

@dp.message_handler(state=adminFSM.model_photo, content_types=['photo'])
async def load_model_photo(message:types.Message, state:FSMContext):
    async with state.proxy() as data:
        data['photo'] = message.photo[-1].file_id
    await insert_mod(state)
    await state.finish()
    await message.answer("Автокөлік сәтті тіркелді")


l = []
for el in cursor.execute('SELECT name FROM model_turleri').fetchall():
    l.append(el[0])

@dp.callback_query_handler()
async def print_models(callback:CallbackQuery):
    global l
    if callback.data in l:
        id = cursor.execute(f"SELECT id FROM model_turleri WHERE name='{callback.data}'").fetchall()[0][0]
        await select_kolik(callback.message, id)
        await callback.answer()
        await select_all_types(callback.message)
    elif "qosu" in callback.data:
        id = int(callback.data[callback.data.find("u")+1:])
        cursor.execute(f'INSERT INTO sebet1(model_id) values({id})')
        base.commit()
        print("OK")
        await callback.answer("Себетке қосылды")
    elif callback.data == "Sebetkeoty":
        await select_sebet(callback.message)
        await callback.answer()
    elif "alu" in callback.data:
        id= int(callback.data[callback.data.find("u")+1:])
        id_del = cursor.execute(f"SELECT id FROM sebet1 WHERE model_id='{id}'").fetchall()
        cursor.execute(f"DELETE FROM sebet1 WHERE id='{id_del[0][0]}'")
        base.commit()
        res = cursor.execute(f"SELECT price FROM models WHERE id='{id}'").fetchall()[0]
        lent = cursor.execute(f"SELECT id FROM sebet1 WHERE model_id='{id}'").fetchall()
        await callback.message.edit_caption(f"Qalgany {res}\n{res}*{len(lent)}")

executor.start_polling(dp, skip_updates=True)